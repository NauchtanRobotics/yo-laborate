#!/usr/bin/env bash

rm -rf output/.tracker/*
rm -rf output/PASCAL_VOC/*
rm -rf output/YOLO_darknet/*

echo "Finished removing all the outputs"
